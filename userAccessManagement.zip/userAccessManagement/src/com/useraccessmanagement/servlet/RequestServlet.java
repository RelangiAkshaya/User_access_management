import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class RequestServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = (String) request.getSession().getAttribute("username");
        String softwareName = request.getParameter("softwareName");
        String accessType = request.getParameter("accessType");
        String reason = request.getParameter("reason");

        // Database connection setup
        try {
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/yourDB", "yourUsername", "yourPassword");

            // Get user ID
            String userQuery = "SELECT id FROM users WHERE username = ?";
            PreparedStatement pstUser = con.prepareStatement(userQuery);
            pstUser.setString(1, username);
            ResultSet rsUser = pstUser.executeQuery();
            int userId = 0;
            if (rsUser.next()) {
                userId = rsUser.getInt("id");
            }

            // Get software ID
            String softwareQuery = "SELECT id FROM software WHERE name = ?";
            PreparedStatement pstSoftware = con.prepareStatement(softwareQuery);
            pstSoftware.setString(1, softwareName);
            ResultSet rsSoftware = pstSoftware.executeQuery();
            int softwareId = 0;
            if (rsSoftware.next()) {
                softwareId = rsSoftware.getInt("id");
            }

            // Insert request
            String requestQuery = "INSERT INTO requests (user_id, software_id, access_type, reason, status) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstRequest = con.prepareStatement(requestQuery);
            pstRequest.setInt(1, userId);
            pstRequest.setInt(2, softwareId);
            pstRequest.setString(3, accessType);
            pstRequest.setString(4, reason);
            pstRequest.setString(5, "Pending");
            pstRequest.executeUpdate();

            con.close();
            response.sendRedirect("requestAccess.jsp?success=true"); // Redirect to access request page with success
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("requestAccess.jsp?error=true"); // Redirect with error
        }
    }
}
