import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class ApprovalServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int requestId = Integer.parseInt(request.getParameter("requestId"));
        String action = request.getParameter("action"); // Approve or Reject

        // Database connection setup
        try {
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/yourDB", "yourUsername", "yourPassword");
            String status = action.equals("Approve") ? "Approved" : "Rejected";

            String query = "UPDATE requests SET status = ? WHERE id = ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, status);
            pst.setInt(2, requestId);
            pst.executeUpdate();

            con.close();
            response.sendRedirect("pendingRequests.jsp?success=true"); // Redirect back to pending requests page
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("pendingRequests.jsp?error=true"); // Redirect with error
        }
    }
}
