import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class SoftwareServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String softwareName = request.getParameter("softwareName");
        String description = request.getParameter("description");
        String accessLevels = String.join(",", request.getParameterValues("accessLevels")); // Multi-select checkbox handling

        // Database connection setup
        try {
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/yourDB", "yourUsername", "yourPassword");
            String query = "INSERT INTO software (name, description, access_levels) VALUES (?, ?, ?)";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, softwareName);
            pst.setString(2, description);
            pst.setString(3, accessLevels);
            pst.executeUpdate();

            con.close();
            response.sendRedirect("createSoftware.jsp?success=true"); // Redirect back to create software page
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("createSoftware.jsp?error=true"); // Redirect with error
        }
    }
}
