import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class SignUpServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String role = "Employee"; // Default role

        // Database connection setup
        try {
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/yourDB", "yourUsername", "yourPassword");
            String query = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, username);
            pst.setString(2, password);
            pst.setString(3, role);
            pst.executeUpdate();

            con.close();
            response.sendRedirect("login.jsp"); // Redirect to login page after successful sign-up
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("signup.jsp?error=true"); // Redirect with error
        }
    }
}
