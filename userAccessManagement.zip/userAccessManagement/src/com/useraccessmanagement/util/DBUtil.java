import java.sql.*;

public class DBUtil {
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/user_access_management"; // Change to your DB URL
    private static final String DB_USERNAME = "postgres"; // Change to your DB username
    private static final String DB_PASSWORD = "123456"; // Change to your DB password

    // Method to get a connection to the database
    public static Connection getConnection() throws SQLException {
        try {
            // Load PostgreSQL JDBC driver
            Class.forName("org.postgresql.Driver");
            return DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new SQLException("PostgreSQL driver not found", e);
        }
    }

    // Utility method for closing resources
    public static void closeResources(Connection con, PreparedStatement pst, ResultSet rs) {
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
